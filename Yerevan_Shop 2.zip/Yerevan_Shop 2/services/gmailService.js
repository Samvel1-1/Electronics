const { google } = require('googleapis');
require('dotenv').config();

// Initialize OAuth2 client using environment variables
// reusing the same logic as server.js to ensure consistency
const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    "https://developers.google.com/oauthplayground"
);

// Set the refresh token
oauth2Client.setCredentials({
    refresh_token: process.env.GOOGLE_REFRESH_TOKEN
});

const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

/**
 * Updates the 'Send Mail As' display name for the authenticated user.
 * @param {string} displayName - The new display name (e.g., "Ktav").
 * @returns {Promise<object>} - The API response.
 */
async function updateGmailDisplayName(displayName) {
    if (!displayName) {
        throw new Error('Display name is required');
    }

    try {
        console.log(`Setting up Gmail service for update...`);
        console.log(`Target Display Name: "${displayName}"`);

        // We need to find the "sendAs" email address. usually it's the primary one.
        // First list the sendAs aliases to find the right one (usually the authenticated user).
        const listRes = await gmail.users.settings.sendAs.list({
            userId: 'me'
        });

        const sendAsEmail = process.env.EMAIL;
        const sendAsEntity = listRes.data.sendAs.find(entry => entry.sendAsEmail === sendAsEmail);

        if (!sendAsEntity) {
            // Fallback: use the first one if env EMAIL doesn't match or isn't set, 
            // but strictly we should use the authenticated user's email.
            // For now, let's try to update the one matching process.env.EMAIL
            console.warn(`Could not find sendAs entry for ${sendAsEmail}. Available: ${listRes.data.sendAs.map(s => s.sendAsEmail).join(', ')}`);
            throw new Error(`No SendAs configuration found for ${sendAsEmail}`);
        }

        console.log(`Found SendAs entry for: ${sendAsEntity.sendAsEmail}. Current name: "${sendAsEntity.displayName}"`);

        const res = await gmail.users.settings.sendAs.patch({
            userId: 'me',
            sendAsEmail: sendAsEntity.sendAsEmail,
            requestBody: {
                displayName: displayName
            }
        });

        console.log('Successfully updated display name!');
        return res.data;

    } catch (error) {
        console.error('Failed to update Gmail display name.');
        if (error.code === 403) {
            console.error('PERMISSION ERROR: The current Refresh Token likely relies on "gmail.send" scope.');
            console.error('You need "https://www.googleapis.com/auth/gmail.settings.basic" scope.');
        }
        throw error;
    }
}

module.exports = { updateGmailDisplayName };

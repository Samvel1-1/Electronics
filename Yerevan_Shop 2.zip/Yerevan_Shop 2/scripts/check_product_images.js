const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

const indexHtml = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');

// Regex to find img properties
const imgRegex = /img:\s*"(https?:\/\/[^"]+)"/g;
let match;
const urls = [];

while ((match = imgRegex.exec(indexHtml)) !== null) {
    urls.push(match[1]);
}

// Check extraction
console.log(`Found ${urls.length} external image URLs to check.`);

async function checkUrl(url) {
    return new Promise((resolve) => {
        const protocol = url.startsWith('https') ? https : http;
        const req = protocol.request(url, { method: 'HEAD', timeout: 5000 }, (res) => {
            if (res.statusCode >= 200 && res.statusCode < 400) {
                resolve({ url, status: 'OK', code: res.statusCode });
            } else {
                resolve({ url, status: 'FAIL', code: res.statusCode });
            }
        });

        req.on('error', (e) => {
            resolve({ url, status: 'ERROR', error: e.message });
        });

        req.on('timeout', () => {
            req.destroy();
            resolve({ url, status: 'TIMEOUT' });
        });

        req.end();
    });
}

async function run() {
    const results = await Promise.all(urls.map(checkUrl));
    const failures = results.filter(r => r.status !== 'OK');

    if (failures.length === 0) {
        console.log("All external images are accessible.");
    } else {
        console.log("The following images failed:");
        failures.forEach(f => console.log(`${f.status} (${f.code || f.error}) - ${f.url}`));
    }
}

run();

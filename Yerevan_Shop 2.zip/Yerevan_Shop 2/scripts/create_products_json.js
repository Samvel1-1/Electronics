const fs = require('fs');
const path = require('path');

const mcProducts = [
    {
        name: "Apple iPhone 17 Pro",
        price: 1500,
        category: "Phones",
        img: "https://www.mobilecentre.am/img/prodpic/0d13f4ff5cb782c9c5e8New_Project_-_2025-09-19T105223.627.png",
        description: `
  <strong>Display:</strong> 6.3-inch Super Retina XDR OLED<br>
  <strong>Processor:</strong> A19 Bionic chip (3nm)<br>
  <strong>Camera:</strong> 48MP Main, 48MP Ultra Wide, 48MP Telephoto (5x Optical Zoom)<br>
  <strong>Battery:</strong> Up to 29 hours video playback<br>
  <strong>Material:</strong> Grade 5 Titanium<br>
  <strong>Radios:</strong> 5G, Wi-Fi 7, Bluetooth 5.4, NFC, Ultra Wideband 2`
    },
    {
        name: "Samsung Galaxy S25 Ultra",
        price: 1000,
        category: "Phones",
        img: "https://www.mobilecentre.am/img/prodpic/ed6f720b90d82108d29cNew_Project__1_.png",
        description: `
  <strong>Display:</strong> 6.8-inch Dynamic AMOLED 2X, 120Hz<br>
  <strong>Processor:</strong> Snapdragon 8 Gen 5 for Galaxy<br>
  <strong>Camera:</strong> 200MP Main, 50MP Periscope, 50MP Ultra Wide<br>
  <strong>Battery:</strong> 5000mAh, 45W charging<br>
  <strong>S Pen:</strong> Built-in S Pen with 2.8ms latency<br>
  <strong>Size:</strong> 162.3 x 79.0 x 8.6 mm`
    },
    {
        name: "Samsung Galaxy S25+",
        price: 900,
        category: "Phones",
        img: "https://www.mobilecentre.am/img/prodpic/6e069e97176168f2d850New_Project__9_.png",
        description: `
  <strong>Display:</strong> 6.7-inch Dynamic AMOLED 2X, QHD+<br>
  <strong>Processor:</strong> Exynos 2500 / Snapdragon 8 Gen 5<br>
  <strong>Camera:</strong> 50MP Main, 12MP Ultra Wide, 10MP Telephoto<br>
  <strong>Battery:</strong> 4900mAh, 45W charging<br>
  <strong>Radios:</strong> 5G, Wi-Fi 6E/7, Bluetooth 5.3`
    },
    {
        name: "Samsung Galaxy Z Fold 7",
        price: 1700,
        category: "Phones",
        img: "https://www.mobilecentre.am/img/prodpic/4b89c1e643a84220b346New_Project_-_2025-07-10T102415.751.png",
        description: `
  <strong>Main Screen:</strong> 7.6-inch QXGA+ Dynamic AMOLED 2X<br>
  <strong>Cover Screen:</strong> 6.2-inch HD+ Dynamic AMOLED 2X<br>
  <strong>Hinge:</strong> Armor Aluminum, IPX8 water resistance<br>
  <strong>Multitasking:</strong> Run up to 3 apps simultaneously<br>
  <strong>Camera:</strong> Under-display camera (4MP), 50MP Rear Triple Cam`
    },
    {
        name: "Sony PlayStation 5 Slim",
        price: 700,
        category: "Console",
        img: "https://www.mobilecentre.am/img/prodpic/e95ab7ec01b41bb95ee1%D0%9D%D0%BE%D0%B2%D1%8B%D0%B9_%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82__15_.png",
        description: `
  <strong>Storage:</strong> 1TB Custom SSD<br>
  <strong>Graphics:</strong> AMD Radeon RDNA 2-based engine, Ray Tracing<br>
  <strong>Resolution:</strong> Up to 4K 120Hz, 8K Output support<br>
  <strong>Dimensions:</strong> 358 x 96 x 216 mm (approx. 30% smaller)<br>
  <strong>Controller:</strong> DualSense Wireless Controller included`
    },
    {
        name: "Apple Airpods 4 (MXP63)",
        price: 150,
        category: "Audio",
        img: "https://www.mobilecentre.am/img/prodpic/518bc216ce0742a8df2aNew_Project__23_.png",
        description: `
  <strong>Audio:</strong> Personalized Spatial Audio with dynamic head tracking<br>
  <strong>Chip:</strong> H2 headphone chip<br>
  <strong>Battery:</strong> Up to 6 hours listening time, 30 hours with case<br>
  <strong>Connectivity:</strong> Bluetooth 5.3<br>
  <strong>Features:</strong> Adaptive EQ, Sweat and water resistant (IPX4)`
    },
    {
        name: "Google Pixel 10 Pro XL",
        price: 1200,
        category: "Phones",
        img: "https://www.att.com/scmsassets/global/devices/phones/google/google-pixel-10-pro-xl/defaultimage/obsidian-hero-zoom.png",
        description: `
  <strong>Display:</strong> 6.9-inch Super Actua Display, LTPO OLED<br>
  <strong>Processor:</strong> Google Tensor G5 (3nm custom silicon)<br>
  <strong>Camera:</strong> 50MP Triple Camera System, AI Magic Editor<br>
  <strong>Battery:</strong> 5500mAh, 45W charging<br>
  <strong>AI:</strong> Gemini Nano integrated`
    },
    {
        name: "Xiaomi 15T Pro",
        price: 800,
        category: "Phones",
        img: "https://www.yerevanmobile.am/media/catalog/product/cache/07720dad39bc68bc6b838050c0f2e34d/q/q/qqeswqeqe32qe342425435.jpg",
        description: `
  <strong>Display:</strong> 144Hz CrystalRes AMOLED<br>
  <strong>Processor:</strong> MediaTek Dimensity 9400<br>
  <strong>Camera:</strong> Leica 200MP Professional System<br>
  <strong>Charging:</strong> 120W HyperCharge (0-100% in 19 mins)<br>
  <strong>Build:</strong> IP68 Dust/Water Resistant`
    },
    {
        name: "Dyson Airwrap Multi-styler",
        price: 600,
        category: "Beauty",
        img: "https://mgviplounge.com/cdn/shop/files/AIRWRAP-BLUE-BLUSH_PDP_HERO.png?v=1720527551",
        description: `
  <strong>Technology:</strong> Coanda airflow no heat damage<br>
  <strong>Attachments:</strong> 6 styling attachments included<br>
  <strong>Motor:</strong> Dyson V9 digital motor<br>
  <strong>Control:</strong> Intelligent heat control (measures 40x/sec)<br>
  <strong>Usage:</strong> Curl, shape, smooth, and hide flyaways`
    },
    {
        name: "JBL PartyBox 310",
        price: 550,
        category: "Audio",
        img: "https://www.thesoundfactor.com/cdn/shop/products/1-500x500.jpg?v=1626264092",
        description: `
  <strong>Sound:</strong> 240W JBL Pro Sound<br>
  <strong>Battery:</strong> 18 hours playtime<br>
  <strong>Light Show:</strong> Dynamic light show synced to beat<br>
  <strong>Inputs:</strong> Mic and Guitar inputs, USB, Bluetooth<br>
  <strong>Portability:</strong> Telescopic handle and built-in wheels`
    },
    {
        name: "MacBook Pro M4",
        price: 2500,
        category: "Laptops",
        img: "images/macbook_pro_m4.png",
        description: `
  <strong>Display:</strong> 14-inch or 16-inch Liquid Retina XDR<br>
  <strong>Processor:</strong> Apple M4, M4 Pro, or M4 Max chip<br>
  <strong>Memory:</strong> Up to 128GB unified memory<br>
  <strong>Storage:</strong> Up to 8TB SSD<br>
  <strong>Battery:</strong> Up to 24 hours battery life<br>
  <strong>Camera:</strong> 12MP Center Stage camera`
    },
    {
        name: "Sony WH-1000XM5",
        price: 350,
        category: "Audio",
        img: "images/sony_wh_1000xm5.png",
        description: `
  <strong>Noise Canceling:</strong> Industry-leading noise canceling with two processors<br>
  <strong>Audio:</strong> High-Resolution Audio wireless<br>
  <strong>Call Quality:</strong> Industry-leading call quality with four microphones<br>
  <strong>Battery:</strong> Up to 30-hour battery life<br>
  <strong>Comfort:</strong> Lightweight design with soft fit leather`
    },
    {
        name: "iPad Pro M4",
        price: 1100,
        category: "Tablets",
        img: "images/ipad_pro_m4.png",
        description: `
  <strong>Display:</strong> Ultra Retina XDR with Tandem OLED technology<br>
  <strong>Processor:</strong> Apple M4 chip<br>
  <strong>Design:</strong> Thinnest Apple product ever<br>
  <strong>Connectivity:</strong> 5G and Wi-Fi 6E<br>
  <strong>Accessory:</strong> Works with Apple Pencil Pro and Magic Keyboard`
    },

    {
        name: "Google Pixel 8 Pro",
        price: 999,
        category: "Phones",
        images: [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1xJgtqbjSwH9diwDTyxoYkjqKPGyox4_JIA&s",
            "https://lh3.googleusercontent.com/O6L6L0x-U-zIu-I5Yq-Rz1k9z3J6L6o-M-qM6w-N-x4M6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6w-N-xM6=w1000"
        ],
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1xJgtqbjSwH9diwDTyxoYkjqKPGyox4_JIA&s",
        description: `
    <strong>Display:</strong> 6.7-inch Super Actua LTPO OLED (1-120Hz)<br>
    <strong>Processor:</strong> Google Tensor G3 coprocessor<br>
    <strong>Camera:</strong> 50MP Main, 48MP Ultrawide, 48MP Telephoto (5x)<br>
    <strong>Battery:</strong> 5050 mAh, 24+ hour battery life<br>
    <strong>AI Features:</strong> Magic Editor, Best Take, Audio Magic Eraser`
    },

    {
        name: "Nintendo Switch OLED",
        price: 350,
        category: "Console",
        img: "images/nintendo_switch_oled.png",
        description: `
    <strong>Display:</strong> 7-inch OLED screen with vibrant colors<br>
    <strong>Modes:</strong> TV, Tabletop, and Handheld modes<br>
    <strong>Storage:</strong> 64 GB internal storage (expandable)<br>
    <strong>Audio:</strong> Enhanced audio for handheld/tabletop play<br>
    <strong>Connectivity:</strong> Wired LAN port in dock, Wi-Fi, Bluetooth 4.1`
    },
    {
        name: "Google Pixel 9 Pro",
        price: 999,
        category: "Phones",
        img: "https://www.dxomark.com/wp-content/uploads/medias/post-176677/Google-Pixel-9-Pro-XL_featured-image-packshot-review.png",
        description: `
    <strong>Display:</strong> 6.3-inch Super Actua LTPO OLED<br>
    <strong>Processor:</strong> Google Tensor G4 (4nm)<br>
    <strong>Camera:</strong> 50MP Main, 48MP Ultrawide, 48MP Telephoto (5x)<br>
    <strong>Battery:</strong> 4700 mAh, 45W wired charging<br>
    <strong>Features:</strong> Satellite SOS, Gemini Nano AI, 7 years updates`
    },
    {
        name: "Samsung Galaxy S24 Ultra",
        price: 1299,
        category: "Phones",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcmR8TatM-f6U9B_t_8cGTk2FX9JX0a10x7w&s",
        description: `
    <strong>Display:</strong> 6.8-inch Dynamic AMOLED 2X QHD+ (2600 nits)<br>
    <strong>Processor:</strong> Snapdragon 8 Gen 3 for Galaxy<br>
    <strong>Camera:</strong> 200MP Main, 50MP Periscope (5x), 12MP Ultrawide<br>
    <strong>Frame:</strong> Titanium frame, Gorilla Glass Armor<br>
    <strong>S Pen:</strong> Integrated S Pen for productivity`
    },
    {
        name: "Apple iPhone 16 Pro Max",
        price: 1199,
        category: "Phones",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_I76Agx_ReOGE0moaVE-KIuJJiYWIn2Zcwg&s",
        description: `
    <strong>Display:</strong> 6.9-inch Super Retina XDR OLED (ProMotion)<br>
    <strong>Processor:</strong> A18 Pro chip (3nm, 6-core GPU)<br>
    <strong>Camera:</strong> 48MP Fusion, 48MP Ultrawide, 12MP Telephoto (5x)<br>
    <strong>Battery:</strong> Best battery life ever in an iPhone<br>
    <strong>Button:</strong> New Camera Control button`
    },
    {
        name: "Xbox Series X",
        price: 499,
        category: "Console",
        img: "https://cms-assets.xboxservices.com/assets/bc/40/bc40fdf3-85a6-4c36-af92-dca2d36fc7e5.png?n=642227_Hero-Gallery-0_A1_857x676.png",
        description: `
    <strong>Performance:</strong> 12 Teraflops, Custom RDNA 2 GPU<br>
    <strong>Gaming:</strong> True 4K gaming, up to 120 FPS, 8K HDR Ready<br>
    <strong>Storage:</strong> 1TB Custom NVMe SSD<br>
    <strong>Features:</strong> Quick Resume, Velocity Architecture, 3D Spatial Sound`
    },
    {
        name: "iPad Pro M4 (13-inch)",
        price: 1299,
        category: "Tablets",
        img: "https://www.trikart.com/media/catalog/product/i/p/ipad_pro_2024_space_black_2_6.jpg?width=2500&auto=webp&quality=90",
        description: `
    <strong>Display:</strong> 13-inch Ultra Retina XDR (Tandem OLED)<br>
    <strong>Processor:</strong> Apple M4 chip (9-core CPU, 10-core GPU)<br>
    <strong>Dimensions:</strong> 5.1mm thin - Thinnest Apple product ever<br>
    <strong>Connectivity:</strong> Wi-Fi 6E, Thunderbolt / USB 4<br>
    <strong>Cameras:</strong> 12MP Wide back, Landscape 12MP Ultra Wide front`
    },
    {
        name: "Dyson Airwrap i.d. multi-styler",
        price: 599,
        category: "Beauty",
        img: "https://eldorado.am/media/catalog/product/cache/b636eac9f5e866652b5cbe8cee86d97c/_/d/_dyson_hs08_airwrap_id_strawberry_bronze_in_100.jpg",
        description: `
    <strong>Technology:</strong> Coanda airflow styling (no extreme heat)<br>
    <strong>Smart:</strong> i.d. curl personalized sequencing<br>
    <strong>Connectivity:</strong> Bluetooth wireless technology<br>
    <strong>Versatility:</strong> Dry, curl, shape, smooth, and hide flyaways`
    },
    {
        name: "Sony WH-1000XM5",
        price: 399,
        category: "Audio",
        img: "https://vega.am/image/cache/catalog/1HRACH/2020/2021/2024/Noyember/Akanjakal/WH-1000XM5%20(Black)%20(3)-2000x1500.jpg",
        description: `
    <strong>Noise Canceling:</strong> Industry-leading ANC with 8 mics<br>
    <strong>Sound:</strong> High-Resolution Audio, LDAC support, DSEE Extreme<br>
    <strong>Calls:</strong> Precise Voice Pickup technology<br>
    <strong>Battery:</strong> 30 hours (ANC on), 3 min charge = 3 hours play`
    },
    {
        name: "MacBook Pro M3 (14-inch)",
        price: 1599,
        category: "Laptops",
        img: "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/mbp14-spaceblack-select-202410_FMT_WHH?wid=986&hei=980&fmt=jpeg&qlt=90&.v=YnlWZDdpMFo0bUpJZnBpZjhKM2M3YnRLQTZRakorT3p3YTRUbVA0N3dnbno1Z1NFZVpQcDI0a3h2dkh0TjNmUjJLTVU0K0hCZXlvVVVTdytIMzZjQXhhU2ZYeWJNaHI5aXZSOWk3dEhoQkx6STlJSlZ4M0pKaFh6c2piamliR2k",
        description: `
    <strong>Display:</strong> 14.2-inch Liquid Retina XDR (1000 nits sustained)<br>
    <strong>Processor:</strong> Apple M3 chip (8-core CPU, 10-core GPU)<br>
    <strong>Battery:</strong> Up to 22 hours video playback<br>
    <strong>Ports:</strong> MagSafe 3, 2x Thunderbolt / USB 4, HDMI, SDXC<br>
    <strong>Memory:</strong> 8GB Unified Memory, 512GB SSD`
    },
    {
        name: "Bose QuietComfort Ultra",
        price: 429,
        category: "Audio",
        img: "https://www.yerevanmobile.am/media/catalog/product/cache/07720dad39bc68bc6b838050c0f2e34d/5/1/51nc9eriqtl._ac_sl1500_.jpg",
        description: `
    <strong>Audio:</strong> Spatial Audio with dynamic head tracking<br>
    <strong>NC:</strong> World-class Active Noise Cancellation<br>
    <strong>Modes:</strong> Quiet, Aware, and Immersion modes<br>
    <strong>Battery:</strong> Up to 24 hours (18 with Immersive Audio)<br>
    <strong>Comfort:</strong> Luxe materials, custom-fit earcups`
    },
    {
        name: "Beats Studio Pro",
        price: 349,
        category: "Audio",
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MTT83?wid=1144&hei=1144&fmt=jpeg&qlt=95&.v=1687550307049",
        description: `
    <strong>Sound:</strong> Custom acoustic platform for rich, immersive sound<br>
    <strong>ANC:</strong> Fully adaptive Active Noise Cancelling + Transparency<br>
    <strong>Format:</strong> Lossless audio via USB-C<br>
    <strong>Battery:</strong> Up to 40 hours total battery life<br>
    <strong>Compatibility:</strong> One-touch pairing for Apple & Android`
    },
    {
        name: "Steam Deck OLED",
        price: 549,
        category: "Console",
        img: "https://clan.cloudflare.steamstatic.com/images/39049601/37b120786937e01f6874e0d4cc4b21b442b080f5.png",
        description: `
    <strong>Display:</strong> 7.4-inch HDR OLED (90Hz, 1000 nits peak)<br>
    <strong>Battery:</strong> 50Wh battery (3-12 hours gameplay)<br>
    <strong>Connectivity:</strong> Wi-Fi 6E for faster downloads<br>
    <strong>Storage:</strong> 512GB or 1TB NVMe SSD<br>
    <strong>Weight:</strong> ~640g (lighter than LCD model)`
    },
    {
        name: "ASUS ROG Ally X",
        price: 799,
        category: "Console",
        img: "https://dlcdnwebimgs.asus.com/gain/49C149C9-8809-4B52-87C2-111E939E8863/w1000",
        description: `
    <strong>System:</strong> Windows 11 Home (Gaming Handheld)<br>
    <strong>Processor:</strong> AMD Ryzen Z1 Extreme<br>
    <strong>Memory:</strong> 24GB LPDDR5X-7500 RAM<br>
    <strong>Battery:</strong> Massive 80Wh battery<br>
    <strong>Ergonomics:</strong> Improved grips and joystick durability`
    },
    {
        name: "iPad Air M2 (11-inch)",
        price: 599,
        category: "Tablets",
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/ipad-air-finish-select-202405-11inch-blue-wifi?wid=1280&hei=720&fmt=p-jpg&qlt=80&.v=1713304153177",
        description: `
    <strong>Display:</strong> 11-inch Liquid Retina display<br>
    <strong>Processor:</strong> Apple M2 chip (Faster performance)<br>
    <strong>Camera:</strong> 12MP Ultra Wide front camera (Landscape)<br>
    <strong>Connectivity:</strong> Wi-Fi 6E, 5G cellular available<br>
    <strong>Support:</strong> Apple Pencil Pro and Magic Keyboard`
    },
    {
        name: "Samsung Galaxy Tab S9",
        price: 799,
        category: "Tablets",
        img: "https://images.samsung.com/is/image/samsung/p6pim/ae/2307/png/ae-galaxy-tab-s9-wifi-x710-sm-x710nzaamea-537482594?$650_519_PNG$",
        description: `
    <strong>Display:</strong> 11-inch Dynamic AMOLED 2X (120Hz)<br>
    <strong>Processor:</strong> Snapdragon 8 Gen 2 for Galaxy<br>
    <strong>Durability:</strong> IP68 water/dust resistant (tablet & S Pen)<br>
    <strong>Battery:</strong> 8400 mAh, 45W charging<br>
    <strong>Included:</strong> Inbox S Pen`
    },
    {
        name: "Microsoft Surface Pro 11",
        price: 999,
        category: "Tablets",
        img: "https://img-prod-cms-rt-microsoft-com.akamaized.net/cms/api/am/imageMW/RW1mC2d?ver=800e&f=jpg&q=90&m=6&h=519&w=923&b=%23FFFFFFFF&l=f&a=c",
        description: `
    <strong>Processor:</strong> Snapdragon X Elite / X Plus (Copilot+ PC)<br>
    <strong>Display:</strong> 13-inch OLED or LCD PixelSense Flow<br>
    <strong>AI:</strong> Neural Processing Unit (NPU) for AI tasks<br>
    <strong>Battery:</strong> Up to 14 hours video playback<br>
    <strong>Flexibility:</strong> Tablet, Laptop, and Studio modes`
    },
    {
        name: "iPad Mini (6th Gen)",
        price: 499,
        category: "Tablets",
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/ipad-mini-select-202109-purple?wid=2560&hei=1440&fmt=p-jpg&qlt=80&.v=1631751017000",
        description: `
    <strong>Display:</strong> 8.3-inch Liquid Retina display<br>
    <strong>Processor:</strong> A15 Bionic chip<br>
    <strong>Cameras:</strong> 12MP Wide back, 12MP Ultra Wide front<br>
    <strong>Wireless:</strong> 5G capable, Wi-Fi 6<br>
    <strong>Portability:</strong> Fits in one hand, Apple Pencil 2 support`
    },
    {
        name: "Dyson Corrale straightener",
        price: 499,
        category: "Beauty",
        img: "https://dyson-h.assets.adidas.com/is/image/dyson/322851-01_1?$pdp_main$",
        description: `
    <strong>Technology:</strong> Flexing manganese copper alloy plates<br>
    <strong>Damage:</strong> Less heat, half the damage<br>
    <strong>Versatility:</strong> Cord-free versatility (up to 30 mins)<br>
    <strong>Settings:</strong> 165°C, 185°C, and 210°C<br>
    <strong>Safe:</strong> Flight-ready tag`
    },
    {
        name: "Shark FlexStyle Air Styling System",
        price: 299,
        category: "Beauty",
        img: "https://www.sharkclean.com/cdn/shop/files/HD430_Shark_FlexStyle_Hair_Styling_Drying_System_Hero.png?v=1708453489",
        description: `
    <strong>System:</strong> Powerful hair dryer and multi-styler<br>
    <strong>Versatility:</strong> Curl, volumize, smooth, and dry<br>
    <strong>Tech:</strong> Coanda technology wraps hair automatically<br>
    <strong>Speed:</strong> Fast drying, no heat damage<br>
    <strong>Weight:</strong> Lightweight and compact`
    },
    {
        name: "Revlon One-Step Volumizer PLUS",
        price: 69,
        category: "Beauty",
        img: "https://www.revlonhairtools.com/cdn/shop/files/Revlon_OneStep_Volumizer_Plus_Hero.png?v=1701234567",
        description: `
    <strong>Design:</strong> 30% smaller oval head for closer styling<br>
    <strong>Coating:</strong> Ceramic Titanium Tourmaline<br>
    <strong>Settings:</strong> Low, Medium, High, and Cool<br>
    <strong>Bristles:</strong> Charcoal-infused bristles<br>
    <strong>Volumome:</strong> Detachable head for travel/storage`
    },
    {
        name: "MacBook Air M3 (13-inch)",
        price: 1099,
        category: "Laptops",
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/mba13-starlight-select-202403?wid=904&hei=840&fmt=jpeg&qlt=90&.v=1708361716570",
        description: `
    <strong>Display:</strong> 13.6-inch Liquid Retina display<br>
    <strong>Processor:</strong> Apple M3 chip (8-core CPU, up to 10-core GPU)<br>
    <strong>Design:</strong> Ultrathin, fanless design (11.5mm thin)<br>
    <strong>Battery:</strong> Up to 18 hours battery life<br>
    <strong>Features:</strong> MagSafe charging, dual external display support`
    },
    {
        name: "Dell XPS 13 (2024)",
        price: 1299,
        category: "Laptops",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Dell_XPS_13_Plus.jpg/640px-Dell_XPS_13_Plus.jpg",
        description: `
    <strong>Processor:</strong> Intel Core Ultra 7 155H<br>
    <strong>Display:</strong> 13.4-inch FHD+ InfinityEdge (500 nits)<br>
    <strong>Design:</strong> Machined aluminum, glass palm rest<br>
    <strong>Memory:</strong> 16GB LPDDR5X, 512GB SSD<br>
    <strong>Weight:</strong> 2.6 lbs (1.19 kg)`
    },
    {
        name: "HP Spectre x360 (14-inch)",
        price: 1449,
        category: "Laptops",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/HP_Spectre_x360_%282020%29.jpg/640px-HP_Spectre_x360_%282020%29.jpg",
        description: `
    <strong>Model:</strong> 14-inch 2-in-1 Laptop (2024)<br>
    <strong>Processor:</strong> Intel Core Ultra 7 155H<br>
    <strong>Display:</strong> 2.8K OLED Touch (120Hz, HDR 500)<br>
    <strong>Audio:</strong> Poly Studio with Quad Speakers<br>
    <strong>Camera:</strong> 9MP AI camera with Night mode`
    },
    {
        name: "Lenovo Yoga 9i Gen 9",
        price: 1399,
        category: "Laptops",
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Lenovo_Yoga_7i_14_ITL5.jpg/640px-Lenovo_Yoga_7i_14_ITL5.jpg",
        description: `
    <strong>Model:</strong> 14-inch 2-in-1 Convertible<br>
    <strong>Processor:</strong> Intel Core Ultra 7 155H<br>
    <strong>Display:</strong> 4K OLED PureSight (Bowers & Wilkins)<br>
    <strong>Sound:</strong> Rotating Soundbar hinge<br>
    <strong>Includes:</strong> Lenovo Slim Pen & Sleeve`
    },
    {
        name: "ASUS ROG Zephyrus G14",
        price: 1599,
        category: "Laptops",
        img: "https://dlcdnwebimgs.asus.com/gain/3D1A3D1A-3D1A-4D1A-BD83-8E56AAEA4F39/w1000",
        description: `
    <strong>Display:</strong> 14-inch ROG Nebula HDR OLED (120Hz)<br>
    <strong>GPU:</strong> NVIDIA GeForce RTX 4070 Laptop GPU<br>
    <strong>Processor:</strong> AMD Ryzen 9 8945HS<br>
    <strong>Build:</strong> CNC Aluminum Chassis (1.59 cm thin)<br>
    <strong>Audio:</strong> 6-speaker system with Dolby Atmos`
    },
    {
        name: "Motorola Edge 50 Pro",
        price: 599,
        category: "Phones",
        img: "https://fdn2.gsmarena.com/vv/bigpic/motorola-edge-50-pro.jpg",
        description: `
    <strong>Display:</strong> 6.7-inch 1.5K pOLED (144Hz, 2000 nits)<br>
    <strong>Charging:</strong> 125W TurboPower, 50W Wireless<br>
    <strong>Camera:</strong> 50MP Main (f/1.4), 10MP Telephoto (3x), 13MP Ultrawide<br>
    <strong>Processor:</strong> Snapdragon 7 Gen 3<br>
    <strong>Build:</strong> IP68 rating, Silicone/Acetate finish`
    },
    {
        name: "Sony Xperia 1 VI",
        price: 1399,
        category: "Phones",
        img: "https://fdn2.gsmarena.com/vv/bigpic/sony-xperia-1-vi.jpg",
        description: `
    <strong>Display:</strong> 6.5-inch FHD+ HDR OLED (120Hz)<br>
    <strong>Camera:</strong> Exmor T sensor, 85-170mm optical zoom<br>
    <strong>Audio:</strong> 3.5mm jack, Full-stage stereo speakers<br>
    <strong>Battery:</strong> 5000 mAh, 2-day battery life<br>
    <strong>Process:</strong> Snapdragon 8 Gen 3`
    },
    {
        name: "OnePlus 12",
        price: 799,
        category: "Phones",
        img: "https://fdn2.gsmarena.com/vv/bigpic/oneplus-12.jpg",
        description: `
    <strong>Performance:</strong> Snapdragon 8 Gen 3, up to 16GB RAM<br>
    <strong>Display:</strong> 2K 120Hz ProXDR Display<br>
    <strong>Camera:</strong> Hasselblad Camera for Mobile (4th Gen)<br>
    <strong>Battery:</strong> 5400 mAh, 80W SUPERVOOC charging<br>
    <strong>Cooling:</strong> Dual Cryo-velocity VC`
    },
    {
        name: "Nokia G42 5G",
        price: 249,
        category: "Phones",
        img: "https://fdn2.gsmarena.com/vv/bigpic/nokia-g42-5g.jpg",
        description: `
    <strong>Sustainability:</strong> Repairable design (QuickFix)<br>
    <strong>Display:</strong> 6.56-inch HD+ 90Hz display<br>
    <strong>Battery:</strong> 3-day battery life (5000 mAh)<br>
    <strong>Camera:</strong> 50MP Triple AI Camera<br>
    <strong>Connectivity:</strong> 5G for fast browsing`
    },
    {
        name: "Nothing Phone (2)",
        price: 599,
        category: "Phones",
        img: "https://fdn2.gsmarena.com/vv/bigpic/nothing-phone2.jpg",
        description: `
    <strong>Design:</strong> Transparent back with Glyph Interface<br>
    <strong>Processor:</strong> Snapdragon 8+ Gen 1<br>
    <strong>Display:</strong> 6.7-inch Flexible LTPO OLED<br>
    <strong>Camera:</strong> Dual 50MP (Main + Ultrawide)<br>
    <strong>OS:</strong> Nothing OS 2.0 (Android)`
    }
];

fs.writeFileSync(path.join(__dirname, '../products.json'), JSON.stringify(mcProducts, null, 2));
console.log('products.json created successfully');

const https = require('https');

const urls = [
    "https://fdn2.gsmarena.com/vv/bigpic/motorola-edge-50-pro.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/sony-xperia-1-vi.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/oneplus-12.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/nokia-g42.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/nothing-phone-2.jpg"
];

async function checkUrl(url) {
    return new Promise((resolve) => {
        const req = https.request(url, { method: 'HEAD', timeout: 5000, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            resolve({ url, status: res.statusCode });
        });
        req.on('error', () => resolve({ url, status: 'ERROR' }));
        req.end();
    });
}

async function run() {
    const results = await Promise.all(urls.map(checkUrl));
    results.forEach(r => console.log(`${r.status} - ${r.url}`));
}

run();

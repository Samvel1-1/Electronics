const https = require('https');

const urls = [
    "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Dell_XPS_13_Plus.jpg/640px-Dell_XPS_13_Plus.jpg",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/HP_Spectre_x360_%282020%29.jpg/640px-HP_Spectre_x360_%282020%29.jpg",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Lenovo_Yoga_7i_14_ITL5.jpg/640px-Lenovo_Yoga_7i_14_ITL5.jpg"
];

async function checkUrl(url) {
    return new Promise((resolve) => {
        const req = https.request(url, { method: 'HEAD', timeout: 5000, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            resolve({ url, status: res.statusCode });
        });
        req.on('error', () => resolve({ url, status: 'ERROR' }));
        req.end();
    });
}

async function run() {
    const results = await Promise.all(urls.map(checkUrl));
    results.forEach(r => console.log(`${r.status} - ${r.url}`));
}

run();

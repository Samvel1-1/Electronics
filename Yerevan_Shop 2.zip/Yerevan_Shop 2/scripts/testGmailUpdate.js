const { updateGmailDisplayName } = require('../services/gmailService');

const newName = process.argv[2] || "Ktav"; // Default to Ktav if not provided

(async () => {
    try {
        console.log(`Starting update process for name: "${newName}"...`);
        const result = await updateGmailDisplayName(newName);
        console.log('Update Complete. Result:', result);
    } catch (error) {
        console.error('Update Failed:', error.message);
        process.exit(1);
    }
})();

const https = require('https');

const urls = [
    "https://fdn2.gsmarena.com/vv/bigpic/nokia-g42-5g.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/nothing-phone-2.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/nothing-phone2.jpg",
    "https://fdn2.gsmarena.com/vv/bigpic/nokia-g42-ofic.jpg"
];

async function checkUrl(url) {
    return new Promise((resolve) => {
        const req = https.request(url, { method: 'HEAD', timeout: 5000, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            resolve({ url, status: res.statusCode });
        });
        req.on('error', () => resolve({ url, status: 'ERROR' }));
        req.end();
    });
}

async function run() {
    const results = await Promise.all(urls.map(checkUrl));
    results.forEach(r => console.log(`${r.status} - ${r.url}`));
}

run();
